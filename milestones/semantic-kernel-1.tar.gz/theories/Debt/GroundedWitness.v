(** * Grounded transport witnesses that CARRY their evidence.

    [CertifiedTransport c] is DATA: the observational, construction
    (inhabitant, exhibition record, lineage graph, grounding), maintenance and
    authority evidence for the candidate [c].  [RPath c x y] is the type of
    grounded transport witnesses between states: a path of grounded crossings,
    each crossing carrying a full [CertifiedTransport].  It is the [GT] of a
    generic [GTransport] ([rich_structure]).

    Erasure forgets in two stages, and both are lossy:

        RPath  --forget-->  OPath (grounded crossings, no certificates)
               --erase-->   [oval x = oval y]   (ordinary substitutability)

    Distinguishability is exhibited by [witness_summary], a projection to
    extractable data (record id, custodian, lineage ground node, coverage). *)

From Coq Require Import List.
Import ListNotations.
From GTC.Core Require Import GroundedTransport Erasure.
From GTC.Debt Require Import Certificates EvidenceObligations.
From GTC.Instances Require Import OriginalGroundedSeamInstance.
From Exactness Require Import GroundedSeam.

Record CertifiedTransport (c : EvCandidate) : Type := {
  ct_observational :
    Admissible (ecMA c) (ecPA c) /\ Admissible (ecMB c) (ecPB c);
  ct_construction : ConstructionCertificate c;
  ct_maintenance : ecMaintenance c;
  ct_authority : ecAuthorisation c
}.
Arguments ct_observational {c} _.
Arguments ct_construction {c} _.
Arguments ct_maintenance {c} _.
Arguments ct_authority {c} _.

Section Rich.
  Context (c : EvCandidate).

  Definition rstate : Type := @ost (ecA c) (ecB c).
  Definition rval : rstate -> bool := oval (ecPA c) (ecPB c).

  Inductive RPath : rstate -> rstate -> Type :=
  | rp_refl  : forall x, RPath x x
  | rp_step  : forall (r : seam (ecSpan c)) (ct : CertifiedTransport c),
      RPath (inl (back (ecSpan c) r)) (inr (fwd (ecSpan c) r))
  | rp_trans : forall x y z, RPath x y -> RPath y z -> RPath x z.

  (** Stage 1: forget the certificates, keep the grounded crossings. *)
  Fixpoint rpath_forget {x y} (w : RPath x y)
    : OPath (ecSpan c) (ecPA c) (ecPB c) (ecPs c) x y :=
    match w with
    | rp_refl x => op_refl _ _ _ _ x
    | rp_step r ct =>
        op_step _ _ _ _ r
          (proj1 (cc_grounding (ct_construction ct) r))
          (proj2 (cc_grounding (ct_construction ct) r))
    | rp_trans _ _ _ w1 w2 => op_trans _ _ _ _ _ _ _ (rpath_forget w1) (rpath_forget w2)
    end.

  (** Stage 2: ordinary substitutability. *)
  Lemma rpath_sound : forall x y, RPath x y -> rval x = rval y.
  Proof. intros x y w. exact (opath_sound _ _ _ _ x y (rpath_forget w)). Qed.

  Definition rich_structure : GTransport rstate (fun x y => rval x = rval y) :=
    {| GT := RPath; gt_refl := rp_refl; gt_compose := rp_trans;
       gt_sound := rpath_sound |}.

  (** ** The extractable summary of a witness *)

  Record WitnessSummary : Type := {
    ws_record : nat;              (* exhibition record id *)
    ws_custodian : nat;           (* custodian *)
    ws_ground : nat;              (* lineage ground node *)
    ws_coverage : nat * nat;      (* exhibition coverage interval *)
    ws_dispositions : nat         (* number of declared lineage dispositions *)
  }.

  Definition ct_summary (ct : CertifiedTransport c) : WitnessSummary :=
    let cc := ct_construction ct in
    {| ws_record := ex_record_id (cc_exhibition cc);
       ws_custodian := ex_custodian (cc_exhibition cc);
       ws_ground := lin_ground (lc_graph (cc_lineage cc));
       ws_coverage := ex_coverage (cc_exhibition cc);
       ws_dispositions := length (lin_dispositions (lc_graph (cc_lineage cc))) |}.

  Fixpoint witness_summary {x y} (w : RPath x y) : list WitnessSummary :=
    match w with
    | rp_refl _ => []
    | rp_step _ ct => [ct_summary ct]
    | rp_trans _ _ _ w1 w2 => witness_summary w1 ++ witness_summary w2
    end.
End Rich.

Arguments rp_refl {c} x.
Arguments rp_step {c} r ct.
Arguments rp_trans {c x y z} _ _.

(** 1. Grounded transport entails ordinary substitutability. *)
Theorem erase_sound (c : EvCandidate) (x y : rstate c) :
  RPath c x y -> rval c x = rval c y.
Proof. exact (rpath_sound c x y). Qed.

(** Every erased witness is extensional agreement, at every crossing. *)
Corollary certified_crossing_erases (c : EvCandidate) (ct : CertifiedTransport c)
    (r : seam (ecSpan c)) :
  erased (rich_structure c) (inl (back (ecSpan c) r)) (inr (fwd (ecSpan c) r)).
Proof. exact (erase (rich_structure c) (rp_step r ct)). Qed.
