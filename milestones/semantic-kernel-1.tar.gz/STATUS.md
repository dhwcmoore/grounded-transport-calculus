# Status (2026-09-21, after the located-evidence assessment milestone)

Reference environment: Coq 8.18.0, OCaml 4.14.1. Builds under `coq_makefile` and
`dune build --root .`. `coqchk` passes on the whole project; on the project
without `ClassicalFactorisation.v` it succeeds and reports no axioms. `Print
Assumptions` is "closed under the global context" for every theorem listed
below except `constant_factors`.

## The test: does grounded transport retain what ordinary rewriting forgets?

Six demonstrations. All are proved, axiom-free, and the evidence is in `Type`
(checked by extraction, below).

| # | Claim | Theorem | File |
|---|---|---|---|
| 1 | grounded transport entails ordinary substitutability | `erase_sound` (via `rpath_sound`) | `Debt/GroundedWitness.v` |
| 2 | ordinary substitutability does not reconstruct grounding | `erasure_not_reflecting`, `copied_ungrounded_agreement` | `examples/CopiedCoordinates.v` |
| 3 | different warrants, same endpoints, identical after erasure | `same_endpoints_different_warrants`, `different_lineage_different_warrant` | `examples/DifferentWarrants.v` |
| 4 | failed transport yields LOCATED evidence, co-occurring | `Located`, `Obstructions` (non-empty), `located_refutes`, `obstructions_refute`, `assemble_refuted_reports_all`, `both_obstructions_reported` | `Debt/TransportAssessment.v`, `examples/MaintenanceFailure.v` |
| 5 | missing evidence is not refutation | `TransportAssessment = Certified | Refuted | Open`; `assemble_status`; `missing_lineage_is_open`, `partial_lineage_is_open`, `three_outcomes_distinct` | same |
| 6 | dynamic failure visible despite extensional persistence | `dynamic_failure_visible`, `ordinary_rewriting_still_succeeds` | `examples/MaintenanceFailure.v` |

### The shape
```
Certified : CertifiedTransport c   -> TransportAssessment c
Refuted   : Obstructions c         -> TransportAssessment c   (head :: tail, non-empty)
Open      : list OpenObligation    -> TransportAssessment c
```
`assemble` builds it from four per-obligation `Verdict`s (`VDischarged | VFailed |
VOpen`). A refuted assembly reports EVERY failed obligation in a fixed order;
`assemble_open_nonempty` shows `Open` is never empty; `assemble_status` is the
manuscript's componentwise rule.

**Indexing deviation from the sketch.** Assessments are indexed by the transport
PROBLEM (`EvCandidate`), not by a pair `(x, y)`. A pair-indexed `Refuted` would be
false at reflexive pairs, where `rp_refl` needs no certificate. Pair witnesses are
derived: `certified_witness_at` gives an `RPath` at every seam crossing.

### What is data now (all `Type`)
- `CertifiedTransport`: observational, construction, maintenance, authority.
- `ConstructionCertificate`: inhabitant, `ExhibitionCertificate` (record id,
  identifiers, process, retained record + evaluator, coverage, custodian),
  `LineageCertificate`, grounding.
- `Lineage` is finite data (lists), mirroring the OCaml record.
  `LineageCertificate` carries graph, `CoverageRecord` (with gaps) and the issued
  `LineageVerdict` as data, plus proofs.
- `RPath`: witnesses, each crossing carrying a full `CertifiedTransport`; the `GT`
  of a generic `GTransport` (`rich_structure`). Erasure is two-stage and lossy:
  `RPath -> OPath` (drop certificates) `-> rval x = rval y` (drop crossings).
- Failures are data: `FibreWitness`, `SeamEmpty`, `GroundingFailure r`,
  `ExhibitionDefeated`, `LineageDescent`, `LineageUndisclosed n`,
  `LineageNoIndependentSource`, `LineageMalformed`, `MaintenanceFailureAt`
  (no evolution, or a lost seam element per evolution).

### Extraction check (`extraction/ExtractAssessment.v`)
The assessments extract to OCaml and the evidence survives: lineage graph,
custodian, record id, coverage, verdict, obstruction constructors and their data
(a seam element, an undisclosed node id). The proof fields vanish. A consumer
(`extraction/inspect_assessment.ml`, run once, 2026-09-21) reports for the
examples: copied -> `Refuted [Construction(LineageDescent)]`; missing/partial
lineage -> `Open`; maintenance lost -> `Refuted [Maintenance]`; copied +
maintenance lost -> `Refuted [Construction(LineageDescent); Maintenance]`;
grounded -> `Certified` with custodian=7 record=1 ground node=5 `LineagePass`.
Not part of `_CoqProject`; build instructions are in the file.

## Layers

1. **Legacy** (`legacy/exactness-2026/`): byte-identical, checksums verified,
   built as library `Exactness`.
2. **Generic calculus** (`theories/{Core,Contexts,Obstructions}`).
3. **Compatibility** (`theories/Instances/Original*.v`).
4. **Assessment** (`theories/Debt/`):
   - *Abstract skeleton*: `Assessment.v` (a refutation is a bare `P -> False`),
     `DebtClassifier`, `OriginalObligations`; kept for the decidable special case
     and `Transportable` correspondence.
   - *Located, evidence-bearing*: `Certificates`, `EvidenceObligations`,
     `GroundedWitness`, `TransportAssessment`, `MaintenanceDebt`.

## Earlier milestones (still valid)
Original-seam reconciliation; dynamic seams (structural naturality, valuation
naturality with `UV`, `PreservesGroundingOnImage`, coverage); extensional
theorem and grounded corollary. See `paper/theorem-ledger.md`.

## Axioms
Kernel axiom-free (`coqchk` succeeds without the classical file; all 32 new
theorems closed under `Print Assumptions`). `constant_factors` is isolated in
`Obstructions/ClassicalFactorisation.v`.

## What a `Certified` assessment does NOT show
Given the declared records and their checks, transport is warranted within the
formal regime. It does not show that the declared lineage includes every real
production path, that raw inputs represent the concrete process, that the state
model fits the real target, that an authority is competent or legitimate, or that
the declared seam is what actually happened. Those are construction and
institutional debt. Certificates are ISSUED outside the kernel.

## What is and is not connected
- `LineagePasses` is a Coq specification of Definition 13 mirroring the OCaml
  audit BY INSPECTION; it is not proved equivalent to it. The OCaml does not build
  kernel certificates. Both use finite data now, but no example runs both.
- OCaml's justified/open-defeater distinction is modelled by `Disposition`, but
  L2 only requires some disposition, as in the OCaml.
- Exhibition conditions (ii), (iv), (v) are recorded, not verified.
- The lineage record is part of the DECLARED problem, so witnesses differing in
  lineage belong to different candidates (`DifferentWarrants.v` compares them via
  the extractable `witness_summary`). The summary projects exhibition and lineage
  data; authority and maintenance evidence also differ in general but are not
  projected (their types are abstract in `EvCandidate`).
- "Only X flagged" means one failure under the declared history stated at the top
  of each example; the categories are diagnostic loci, not a partition.

## Open
1. Formalise the audit algorithm in Coq (Boolean, with a reflection theorem),
   extract it, compare with or replace the handwritten lineage section.
2. Coverage-qualified passes ("pass relative to L") as a first-class result, not
   only an `Open` reason; several candidate grounds.
3. Functoriality over a whole interval `I_t`, not one transition.
4. A second concrete `EvCandidate` from the tax-jurisdiction case study.
5. `OpenReason` is a small fixed enumeration.
6. Phase 6, rewriting tactics: still deliberately not started; the semantics they
   would rest on now exist.
