# Theorem ledger

Status: **existing** (legacy supplement, checked there and re-checked here as the
library `Exactness`), **recovered** (existing result re-derived from the generic
calculus, statement unchanged), **new**, **conjectural**.

| Result | Status | Location |
|---|---|---|
| Admissibility characterisation (Thm 2.3) | existing | admissibility paper |
| `fibre_constant_admissible`, `witness_refutes` | existing | `legacy/.../Admissibility.v` |
| Fibre obstruction (generic) | new; legacy `witness_refutes` recovered from it | `Obstructions/FibreObstruction.v`, `Instances/OriginalAdmissibility.v` |
| Fibre factorisation, functional converse | new, **classical axioms**, isolated | `Obstructions/ClassicalFactorisation.v` |
| `evolution_id`, `evolution_compose` | existing | `legacy/.../GroundedSeam.v` |
| `seam_transport`, `seam_transport_admissible` | existing; **recovered** exactly | `Instances/OriginalGroundedSeamInstance.v` |
| `copied_not_grounded` (+ `copied_extensionally_coherent`) | existing; **recovered** from generic obstruction | same |
| Boolean reflection, extraction boundary | existing, not ported | legacy |
| Lineage audit (Definition 12, OCaml) | existing; not connected to Coq | `legacy/.../jurisdiction.ml` |
| `GTransport`, `gt_refl`, `gt_compose` | new | `Core/GroundedTransport.v` |
| `erasure_sound`, erased preorder, exact recovery under completeness | new | `Core/Erasure.v` |
| Grounded does not imply-collapse: `pairwise_agreement_not_grounding` | new (uses legacy lemmas) | `Instances/OriginalGroundedSeamInstance.v` |
| `original_grounding_erases_to_extensional` | new | same |
| `GroundedProper`, `gp_comp`, contextual preservation | new | `Contexts/` |
| Extensional factor transport; grounded corollary | new; `seam_transport` recovered as the corollary | `Instances/OriginalGroundedSeamInstance.v` |
| Valuation naturality (with value transport) => preservation on the image | new | `Instances/OriginalDynamicSeamInstance.v` |
| Surjective evolution preserves all grounding | new | same |
| `SeamEvolution` grounded-proper under `PreservesGroundingOnImage` | new (hypothesis exposed in the name) | same |
| Structural naturality does not give preservation; preservation does not give coverage | new (examples) | `examples/MaintenanceFailure.v`, `examples/EvolutionCoverage.v` |
| Exhibition and lineage certificates; Definition 13 as a specification | new | `Debt/Certificates.v` |
| Three-way assessment; certification, refutation, underdetermination theorems | new | `Debt/Assessment.v` |
| Boolean classifier as decidable special case | new | `Debt/Assessment.v` |
| Certificate -> `Transportable` -> witness -> erasure | new | `Debt/EvidenceObligations.v` |
| Data-bearing `CertifiedTransport`, `RPath` witnesses, `rich_structure` (a `GTransport`) | new | `Debt/GroundedWitness.v` |
| Located obstructions; `TransportAssessment` (Certified / Refuted / Open); `assemble` and its status, non-emptiness and reporting theorems | new | `Debt/TransportAssessment.v` |
| Erasure not reflecting; different warrants same endpoints; dynamic failure invisible to ordinary rewriting | new (examples) | `examples/CopiedCoordinates.v`, `DifferentWarrants.v`, `MaintenanceFailure.v` |
| Evidence survives extraction (OCaml consumer) | checked, not a theorem | `extraction/` |
| Lineage obstruction | new | `Obstructions/LineageObstruction.v` |
| Debt classifier: soundness, relative completeness | new | `Debt/DebtClassifier.v` |
| Four debts bound to `Transportable` (Prop interface layer); maintenance bound to `SeamEvolution` | new | `Debt/OriginalObligations.v`, `Debt/MaintenanceDebt.v` |
| Coq lineage audit proved equivalent to the OCaml audit; extracted certificates | conjectural | - |
| Regional obstruction; fork/order/quorum obstructions | existing, separate | - |
